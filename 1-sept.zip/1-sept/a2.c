#include<stdio.h>

void main() {

	int x,y;
	printf("Enter int x and y :");
	scanf("%d %d",&x,&y);

	int temp;

	printf("Before Swap x = %d and y = %d\n",x,y);
	temp = x;
	x = y;
	y = temp;
	printf("After Swap x = %d and y = %d\n",x,y);

}
