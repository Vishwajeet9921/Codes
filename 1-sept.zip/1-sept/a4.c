#include<stdio.h>

void main() {
	char p = 'A', q = 'a';
	for(int i = 0;i<=4;i++){

		for(int j = 0;j<=i;j++){
			if(i%2!=0)
				printf("%c ",p);
			else
				printf("%c ",q);
		
		}
		printf("\n");
	}
}
