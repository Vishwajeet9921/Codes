#include<stdio.h>

void main() {

	int x;
	printf("Enter range :");
	scanf("%d",&x);

	for(int i = 2;i<=x;i +=2){

			printf("Cube of %d : %d and Square of %d : %d\n",i,i*i*i,i,i*i);
	}

}
