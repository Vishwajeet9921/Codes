#include<stdio.h>

void main() {

	int x,y;
	printf("Enter number x and y :");
	scanf("%d %d",&x,&y);

	if(x>y)
		printf("The maximum number amongst %d & %d is %d\n",x,y,x);
	else if(y>x)
		printf("The maximum number amongst %d & %d is %d\n",x,y,y);
	else
		printf("x and y are equal\n");

}
